import { useEffect, useRef, useContext, useState } from 'react';
import { formatMessageTime } from '../lib/utils';
import assets from '../assets/assets';
import { ChatContext } from '../context/ChatContext';
import './ChatContainer.css';
import { AuthContext } from '../context/AuthContext';
import toast from 'react-hot-toast';

const ChatContainer = () => {
  const { selectedUser, setSelectedUser, messages, sendMessage, getMessages } = useContext(ChatContext);
  const { authUser, onlineUsers } = useContext(AuthContext);
  const scrollEnd = useRef(null);
  const [input, setInput] = useState('');

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (input.trim() === "") return null;
    await sendMessage({ text: input.trim() });
    setInput("");
  }

  const handleSendImage = async (e) => {
    const file = e.target.files[0];
    if (!file || !file.type.startsWith('image/')) {
      toast.error('Select an image file');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      await sendMessage({ image: reader.result });
      e.target.value = "";
    }
    reader.readAsDataURL(file);
  }

  useEffect(() => {
    if (scrollEnd.current && messages) {
      scrollEnd.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  useEffect(() => {
    if (selectedUser) {
      getMessages(selectedUser._id);
    }
  }, [selectedUser]);

  if (!selectedUser) {
    return (
      <div className="chat-empty">
        <img src={assets.logo_icon} alt="logo" />
        <h3>Welcome to QuickChat</h3>
        <p>Select a user from the sidebar to start chatting</p>
      </div>
    );
  }

  return (
    <div className="chat-container">
      {/* Header */}
      <div className="chat-header">
        <img src={selectedUser?.profilePic || assets.avatar_icon} alt="profile" />

        <div className="chat-user">
          <span>{selectedUser?.fullName || 'Unknown User'}</span>
          <span className="online-dot"></span>
        </div>

        <img
          src={assets.arrow_icon}
          alt="back"
          className="back-btn"
          onClick={() => setSelectedUser(null)}
        />

        <img
          src={assets.help_icon}
          alt="help"
          className="help-btn"
        />
      </div>

      {/* Messages */}
      <div className="chat-messages">
        {messages && messages.length > 0 ? (
          messages.map((msg, index) => {
            const isConsecutive = index > 0 && messages[index - 1].senderId === msg.senderId;
            const isSent = msg.senderId === authUser?._id;

            return (
              <div
                key={msg._id || index}
                className={`message-row ${isSent ? 'sent' : 'received'} ${isConsecutive ? 'consecutive' : ''}`}
              >
                {/* For received messages show avatar on the left */}
                {!isSent && !isConsecutive && (
                  <div className="message-meta">
                    <img
                      src={selectedUser?.profilePic || assets.avatar_icon}
                      alt="avatar"
                    />
                    <span>{formatMessageTime(msg.createdAt)}</span>
                  </div>
                )}

                <div className="message-content">
                  {msg.image ? (
                    <img src={msg.image} className="message-image" alt="sent" />
                  ) : (
                    <div className="message-bubble">
                      {msg.text}
                    </div>
                  )}
                </div>

                {/* For sent messages show avatar on the right */}
                {isSent && !isConsecutive && (
                  <div className="message-meta">
                    <img
                      src={authUser?.profilePic || assets.avatar_icon}
                      alt="avatar"
                    />
                    <span>{formatMessageTime(msg.createdAt)}</span>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="no-messages">
            <p>No messages yet. Start the conversation!</p>
          </div>
        )}
        <div ref={scrollEnd}></div>
      </div>

      {/* Input */}
      <div className="chat-input">
        <input 
          type="text" 
          placeholder="Send a message" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" ? handleSendMessage(e) : null}
        />

        <div className="input-actions">
          <input
            type="file"
            id="image"
            accept="image/png, image/jpeg"
            hidden
            onChange={handleSendImage}
          />
          <label htmlFor="image" className="input-icon">
            <img src={assets.gallery_icon} alt="gallery" />
          </label>
          
          <button className="send-button" type="button" onClick={handleSendMessage} aria-label="Send message">
            <img src={assets.send_button} alt="send" />
            <span className="visually-hidden">Send</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatContainer;